using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;

public class NewExpression : MonoBehaviour
{
    
    int minuend,subtrahend;
    int[] digits = new int[3];
    //H1 means seat of hundered and H11 means H1 of minuend, T1 for Tens,O1 for Ones,
    public TextMeshProUGUI H11,T11,O11;
    //H1 means seat of hundered and H12 means H1 of subtrahend, same as above
    public TextMeshProUGUI H12, T12, O12;

    void Start()
    {
        
    }

    
    void Update()
    {
        
    }
    public void createNewExpression()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
    public void generateRandomNumbers()
    {
        minuend = UnityEngine.Random.Range(1, 999);
        subtrahend = UnityEngine.Random.Range(0, minuend);

        string minuendString = minuend.ToString();
        int i = 0;
        //Debug.Log("Minuend Random Generated: " + minuend);
        foreach (char digitChar in minuendString)
        {
            int digit = int.Parse(digitChar.ToString());
            digits[i] = digit;
            i++;
        }

        H11.text = "" + digits[0];
        T11.text = "" + digits[1];
        O11.text = "" + digits[2];

        string subtrahendString = subtrahend.ToString();
        i = 0;
        //Debug.Log("Minuend Random Generated: " + subtrahend);
        foreach (char digitChar in subtrahendString)
        {
            int digit = int.Parse(digitChar.ToString());
            digits[i] = digit;
            i++;
        }
        H12.text = "" + digits[0];
        T12.text = "" + digits[1];
        O12.text = "" + digits[2];

        //Debug.Log("Minuend Digits: ");
        /*for (int j = 0; j < digits.Length; j++)
        {
            Debug.Log(digits[j]);
        }*/
    }
}
