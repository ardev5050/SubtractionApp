using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class GeneratedNumberShapes : MonoBehaviour
{
    public Sprite[] sprites_1_10 = new Sprite[10];
    public Sprite[] sprites_10_90 = new Sprite[9];
    public Sprite[] sprites_100_1000 = new Sprite[10];

    public Image[] minuendImages = new Image[3];
    public Image[] subtrahendImages = new Image[3];

    public TextMeshProUGUI H11, T11, O11;
    public TextMeshProUGUI H12, T12, O12;

    public GameObject H11p, T11p, O11p;
    public GameObject H12p, T12p, O12p;




    void Start()
    {
        
    }

    
    void Update()
    {
        
    }
    public void generateFirstNumberImages()
    {
        int i = 1;
        bool flag = true;
        int j = 0;
        bool H11Found = false, T11Found = false, O11Found = false;
        

        //For 1 - 9,10-90,100-900
        while (i < 10 && flag)
        {
            if (H11.text == "" + i && !H11Found)
            {
                //adjust_panel_size(sprites_100_1000[i - 1],H11p);
                minuendImages[0].sprite = sprites_100_1000[i-1];
                H11Found = true;
            }
            if (T11.text == "" + i && !T11Found)
            {
                adjust_panel_size(sprites_10_90[i - 1], T11p);
                minuendImages[1].sprite = sprites_10_90[i-1];
                T11Found = true;
            }
            if (O11.text == "" + i && !O11Found)
            {
                adjust_panel_size(sprites_1_10[i - 1], O11p);
                minuendImages[2].sprite = sprites_1_10[i-1];
                O11Found = true;
            }
            if(H11Found == true && T11Found == true && O11Found == true) 
            {
                flag = false;
            }
            i++;
        }
    }
    public void generateSecondNumberImages()
    {
        int i = 1;
        bool flag = true;
        int j = 0;
        bool H12Found = false, T12Found = false, O12Found = false;

        //For 1 - 9,10-90,100-900
        while (i < 10 && flag)
        {
            if (H12.text == "" + i && !H12Found)
            {
                //adjust_panel_size(sprites_100_1000[i - 1],H11p);
                subtrahendImages[0].sprite = sprites_100_1000[i - 1];
                H12Found = true;
            }
            if (T12.text == "" + i && !T12Found)
            {
                adjust_panel_size(sprites_10_90[i - 1], T12p);
                subtrahendImages[1].sprite = sprites_10_90[i - 1];
                T12Found = true;
            }
            if (O12.text == "" + i && !O12Found)
            {
                adjust_panel_size(sprites_1_10[i - 1], O12p);
                subtrahendImages[2].sprite = sprites_1_10[i - 1];
                O12Found = true;
            }
            if (H12Found == true && T12Found == true && O12Found == true)
            {
                flag = false;
            }
            i++;
        }
    }

    public void adjust_panel_size(Sprite sprite, GameObject imagePanel)
    {
        RectTransform panelRect = imagePanel.GetComponent<RectTransform>();
        panelRect.sizeDelta = new Vector2(sprite.rect.width, sprite.rect.height);
    }
}
