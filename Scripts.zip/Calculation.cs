using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;


public class Calculation : MonoBehaviour
{
    //these array contains the sprites of 10-90 and 100-900
    public Sprite[] numbers_1_9 = new Sprite[9];
    public Sprite[] numbers_10_90 = new Sprite[9];
    public Sprite[] numbers_100_900 = new Sprite[9];

    //it contains 10's and 90's sprites
    public Sprite[] borrowableNumberSprites = new Sprite[2];

    public Sprite minusSprite = null;

    //Text of 3 digits of Minuend and Subtrahend
    public TextMeshProUGUI H11, T11, O11;
    public TextMeshProUGUI H12, T12, O12;

    //Images of minuend and subtrahend
    public Image ImageH11, ImageT11,ImageO11;
    public Image ImageH12, ImageT12, ImageO12;

    
    //b1m : BOX 1 Minuend, b1s, Box 1 subtrahend, b1b box 1 borrowed number
    public Image b1m, b1s, b1b;
    public Image b2m, b2s, b2b;
    public Image b3m, b3s;
    public Image b4m, b4s, b4b;

    //Empty Objects containing b3b and b3b2
    public GameObject b3b, b3b2;
    //minus operators image
    public Image minusImage,minusImage2,minusImage3;

    //Numbers in the 4 boxes of answer
    public TextMeshProUGUI b1Number, b2Number, b3Number, b4Number;


    public static float delay = 2f;
    public static float defaultDelay = delay;
    //these variables for 3 digits in minuend
    public int n11, n12, n13;

    //and these variables for 3 digits in subtrahend
    public int n21, n22, n23;

    //storing original digits
    public int[] numbers;
    
    private int answer;
    private Coroutine myCoroutine;

    public bool isPaused = false;
    void Start()
    {
       
    }


    public void resetValues()
    {
        Time.timeScale = 1f;
        b4m.sprite = b4s.sprite = b4b.sprite = b3s.sprite = b3m.sprite
        = b2m.sprite = b2s.sprite = null;
        isPaused = false;
        b1Number.text = b2Number.text = b3Number.text = b4Number.text = "0";

        minusImage.sprite = minusImage2.sprite = minusImage3.sprite = null;

        H11.text = "" + numbers[0];
        T11.text = "" + numbers[1];
        O11.text = "" + numbers[2];

        H12.text = "" + numbers[3];
        T12.text = "" + numbers[4];
        O12.text = "" + numbers[5];
    }
    public void removePreviousValues()
    {
        Time.timeScale = 1f;
        b4m.sprite = b4s.sprite = b4b.sprite = b3s.sprite = b3m.sprite
        = b2m.sprite = b2s.sprite = null;
        b1Number.text = b2Number.text = b3Number.text = b4Number.text = "0";
        minusImage.sprite = minusImage2.sprite = minusImage3.sprite = null;
    }
    public void StartCalculation()
    {
        if (myCoroutine != null)
        {
            Debug.Log("Coroutine Stopped");
            StopCoroutine(myCoroutine);
            myCoroutine = null;
        }
        
        myCoroutine = StartCoroutine(SubtractValues());
    }
    IEnumerator SubtractValues()
    {
        n11 = int.Parse(H11.text);
        n12 = int.Parse(T11.text);
        n13 = int.Parse(O11.text);

        n21 = int.Parse(H12.text);
        n22 = int.Parse(T12.text);
        n23 = int.Parse(O12.text);

        //storing original digits for later use in restart 
        numbers = new int[] { n11, n12, n13, n21, n22, n23 };

        //Solving ones/box-4 first which will have o11 and o12----------------------------------
        if(n13 != 0)
        { 
            yield return new WaitForSeconds(delay);
            b4m.sprite = ImageO11.sprite;
            SetSprite(b4m, ImageO11.sprite);
            ImageO11.sprite = null;
        }

        if(n23 != 0)
        { 
            yield return new WaitForSeconds(delay);
            minusImage.sprite = minusSprite;
            b4s.sprite = ImageO12.sprite;
            SetSprite(b4s, ImageO12.sprite);
            ImageO12.sprite = null;
        }


        yield return new WaitForSeconds(delay);

        //checking if n1 is smaller than n2 if yes, then going for borrow from n12 
        //if statement will execute if we need to borrow from seat of ten
        if (n13 < n23)
        {

            b3m.sprite = ImageT11.sprite;
            SetSprite(b3m, ImageT11.sprite);
            ImageT11.sprite = null;
            yield return new WaitForSeconds(delay);
            
            if (n12 >= 1)
            {
                b4b.sprite  = borrowableNumberSprites[0];
                SetSprite(b4b, borrowableNumberSprites[0]);
                adjustTenGiver(b3m, n12);
                n12 -= 1;
            }
            else
            {
                b2m.sprite = ImageH11.sprite;
                SetSprite(b2m, ImageH11.sprite);
                ImageH11.sprite = null;
                yield return new WaitForSeconds(delay);
                adjustTensInCaseOfZero(b3m, n12);
                adjustSeatOfHundred(b2m,n11);
                yield return new WaitForSeconds(delay);
                b4b.sprite = borrowableNumberSprites[0];
                SetSprite(b4b, borrowableNumberSprites[0]);
                b3b2.SetActive(false);
            }
            
            n13 = 10 + n13;
            answer = n13 - n23; 
            
        }

        //else statement will be executed when we don't need to borrow

        else 
        {
            answer = n13 - n23;
            
        }
        yield return new WaitForSeconds(delay);
        b4m.sprite = null;
        b4s.sprite = null;
        b4b.sprite = null;
        minusImage.sprite = null;
        b4Number.text = "" + answer;
        setOnesSprite(b4m, answer);

        //Solving tens--------------------------------------------

        yield return new WaitForSeconds(delay);
        if (ImageT11.sprite != null) 
        {
            b3m.sprite = ImageT11.sprite;
            SetSprite(b3m, ImageT11.sprite);
            ImageT11.sprite = null;
        }
        
        yield return new WaitForSeconds(delay);
        minusImage2.sprite = minusSprite;
        b3s.sprite = ImageT12.sprite;
        SetSprite(b3s, ImageT12.sprite);
        ImageT12.sprite = null;

        yield return new WaitForSeconds(delay);

        //if statement will execute if we need to borrow from seat of ten

        if (n12 < n22)
        {

            b2m.sprite = ImageH11.sprite;
            SetSprite(b2m, ImageH11.sprite);
            ImageH11.sprite = null;

            yield return new WaitForSeconds(delay);
            b3b.SetActive(true);
            b3b2.SetActive(true);
            yield return new WaitForSeconds(delay);

            Debug.Log("Brrowed from b2m for b3b");

            b3b.SetActive(true); //this is the point when borrow from b2m
            //SetSprite(b3b, borrowableNumberSprites[1]);
            b3b2.SetActive(true);
            //SetSprite(b3b2, numbers_10_90[0]);

            Debug.Log("b3b2 is set");
            
            adjustSeatOfHundred(b2m, n11);
            n11 = n11 - 1;
            n12 = 10 + n12;
            answer = n12 - n22;
            
        }

        //else statement will be executed when we don't need to borrow

        else
        {
            answer = n12 - n22;
            
        }
        b3m.sprite = null;
        b3s.sprite = null;
        b3b.SetActive(false);
        b3b2.SetActive(false);
        minusImage2.sprite = null;
        b3Number.text = "" + answer;
        setTensSprite(b3m, answer);

        //solving hundereds---------------------------

        yield return new WaitForSeconds(delay);
        if (ImageH11.sprite != null)
        {
            b2m.sprite = ImageH11.sprite;
            SetSprite(b2m, ImageH11.sprite);
            ImageH11.sprite = null;
        }
        yield return new WaitForSeconds(delay);
        minusImage3.sprite = minusSprite;
        b2s.sprite = ImageH12.sprite;
        SetSprite(b2s, ImageH12.sprite);
        ImageH12.sprite = null;

        yield return new WaitForSeconds(delay);

        answer = n11 - n21;
        b2Number.text = "" + (n11 - n21);
        b2m.sprite = null;
        b2s.sprite = null;
        minusImage3.sprite = null;
        setHunderedsSprite(b2m, answer);

    }

    public void setOnesSprite(Image image,int  number)
    {
        if (number > 0) 
        {
            image.sprite = numbers_1_9[number-1];
            SetSprite(image, numbers_1_9[number - 1]);
        }    
        else
        {
            image.sprite = null;
        }
    }
    public void setTensSprite(Image image, int number)
    {
        if (number > 0)
        {
            image.sprite = numbers_10_90[number-1];
            SetSprite(image, numbers_10_90[number - 1]);
        }
        else
        {
            image.sprite = null;
        }
    }
    public void setHunderedsSprite(Image image, int number)
    {
        if (number > 0)
        {
            image.sprite = numbers_100_900[number-1];
            SetSprite(image, numbers_100_900[number - 1]);
        }
        else
        {
            image.sprite = null;
        }
    }
    public void adjustTenGiver(Image image,int number)
    {
        //image is b3m the minuend of box 3

        int i = 10;
        bool flag = true;
        while (i > 1 && flag)
        {
            if (number == i)
            {
                image.sprite = numbers_10_90[i-2];
                SetSprite(image, numbers_10_90[i-2]);
                flag = false;
            }
            i--;
        }
        if (number == 1 && flag)
        {
            image.sprite = null;
        }
        
    }
    public void adjustTensInCaseOfZero(Image image,int number)
    {
        //image is b3m here
        image.sprite = borrowableNumberSprites[1];
        SetSprite(image, borrowableNumberSprites[1]);
        b3b2.SetActive(true);
        //SetSprite(b3b2, numbers_10_90[0]);
    }
    public void adjustSeatOfHundred(Image image,int number)
    {
        //image is b2m,number is n11
        int i = 9;
        bool flag = true;
        while (i > 1 && flag)
        {
            if (number == i)
            {
                image.sprite = numbers_100_900[i - 2];
                SetSprite(image, numbers_100_900[i-2]);
                flag = false;
            }
            i--;
        }
        if (number == 1 && flag)
        {
            image.sprite = null;
        }
    }
    public void SetSprite(Image image,Sprite sprite)
    {
        // Calculate the scale factor

        float scaleFactor = Mathf.Min(70 / sprite.rect.width, 70 / sprite.rect.height);

        // Set the sprite to the image component with scaling
        image.sprite = sprite;
        image.rectTransform.sizeDelta = new Vector2(sprite.rect.width * scaleFactor, sprite.rect.height * scaleFactor);
    }

    public void SetSpeedToHalf()
    {
        
        delay = delay * 1.5f;
    }
    public void SetSpeedToNormal()
    {
        delay = defaultDelay;
    }
    public void SetSpeedToOneAndHalf()
    {
        delay = delay / 2;
    }
    public void pauseOrPlay()
    {
        if (!isPaused) 
        {
            Time.timeScale = 0f;
            isPaused = true;
        }
        else
        {
            Time.timeScale = 1f;
            isPaused = false;
        }
    }
    public void play()
    {
        
    }
}
